INSERT INTO [dbo].[deploy]([dpy_jira],[dpy_nombre],[dpy_version],[dpy_fecha_hora],[dpy_obs])
VALUES ('SUP2043-90','Depuracion programada',1,GETDATE(),'')
GO
